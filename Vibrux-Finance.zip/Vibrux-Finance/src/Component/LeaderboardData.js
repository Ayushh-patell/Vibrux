export const leaderboardData = [
    {
        "address": "0x1ccd8ff59612d4108d9bbe5f16add545efc6fdbe",
        "invested": "3287.16",
        "vaults": "9",
        "trenches": "2",
        "points": "275"
    },
    {
        "address": "0x558afca8d68f6a7335837b06ce218a234978225b",
        "invested": "2981.72",
        "vaults": "24",
        "trenches": "14",
        "points": "260"
    },
    {
        "address": "0x558gfa539h8f6a7335837b0t43qrf9349r43rdr0",
        "invested": "2410.00",
        "vaults": "13",
        "trenches": "33",
        "points": "125"
    },
    {
        "address": "0x1ba7cfd4293e7d9ab8c5ae745d0f826d64a92eb4",
        "invested": "2106.00",
        "vaults": "20",
        "trenches": "16",
        "points": "120"
    },
    {
        "address": "0x28d593e6a4c38a25e7d95c2fb58a5c792e826987",
        "invested": "1985.54",
        "vaults": "8",
        "trenches": "7",
        "points": "115"
    },
    {
        "address": "0x3198b45c76b4fb09017a0059db5aaaf8c2332f22",
        "invested": "1205.78",
        "vaults": "18",
        "trenches": "30",
        "points": "110"
    },
    {
        "address": "0x4c13fb5368c49d502754c97e0f8b65aa1d7c8d8c",
        "invested": "875.62",
        "vaults": "6",
        "trenches": "20",
        "points": "105"
    },
    {
        "address": "0x5e781dd30aa905c47a48a04e8be5c4f3ae20e1a7",
        "invested": "621.19",
        "vaults": "25",
        "trenches": "5",
        "points": "100"
    },
    {
        "address": "0x6952e816e5c9cd54e6dd7fc7bfe8d12d6d33e09d",
        "invested": "541.00",
        "vaults": "12",
        "trenches": "1",
        "points": "95"
    },
    {
        "address": "0x2e19f6ab90f4e48fece7e11098e0c1b931899029",
        "invested": "487.68",
        "vaults": "30",
        "trenches": "22",
        "points": "90"
    },
    {
        "address": "0x3a5b5b0de2e3f65c4b3b43de9c42c0d8256bcf27",
        "invested": "307.71",
        "vaults": "3",
        "trenches": "39",
        "points": "85"
    }

]