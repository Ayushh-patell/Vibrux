export const DashboardData = [
    {
        TVL:"0.00",
        tokens:["wETH", "USDC"],
        fixedY:"15%",
        variableY:"",
        boosted:true
    },
    {
        TVL:"0.00",
        tokens:["wETH", "BTC.B"],
        fixedY:"",
        variableY:"",
        boosted:false
    },
    {
        TVL:"0.00",
        tokens:["wETH", "USDT"],
        fixedY:"",
        variableY:"",
        boosted:true
    },
    {
        TVL:"0.00",
        tokens:["BTC.B", "USDC"],
        fixedY:"8%",
        variableY:"8.3%",
        boosted:false
    },
    {
        TVL:"0.00",
        tokens:["BTC.B", "BTC.B"],
        fixedY:"",
        variableY:"",
        boosted:false
    },
    {
        TVL:"0.00",
        tokens:["USDC", "USDC"],
        fixedY:"",
        variableY:"",
        boosted:false
    }
]